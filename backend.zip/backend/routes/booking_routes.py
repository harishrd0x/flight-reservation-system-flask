from flask import Blueprint, request, jsonify
from models.booking import Booking
from extensions import db
from flask_jwt_extended import jwt_required, get_jwt_identity

booking_bp = Blueprint("booking", __name__)

@booking_bp.route("/", methods=["GET"])
@jwt_required()
def get_bookings():
    """
    Retrieve all bookings for the authenticated user.
    """
    user_id = get_jwt_identity()
    bookings = Booking.query.filter_by(user_id=user_id).all()
    return jsonify([booking.to_dict() for booking in bookings]), 200

@booking_bp.route("/", methods=["POST"])
@jwt_required()
def create_booking():
    """
    Create a new booking.
    """
    data = request.json
    user_id = get_jwt_identity()

    booking = Booking(
        user_id=user_id,
        flight_id=data.get("flight_id"),
        booking_status=data.get("booking_status", "PENDING")
    )
    
    db.session.add(booking)
    db.session.commit()

    return jsonify({"message": "Booking created", "booking": booking.to_dict()}), 201
