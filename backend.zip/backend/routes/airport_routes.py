from flask import Blueprint, request, jsonify
from flask_cors import CORS
from extensions import db
from models.airport import Airport

airport_bp = Blueprint("airport_bp", __name__, url_prefix="/airports")
CORS(airport_bp)  # ✅ Enable CORS on this blueprint

@airport_bp.route("/", methods=["OPTIONS"])
def handle_options():
    """Handle CORS preflight requests"""
    response = jsonify({"message": "CORS preflight handled"})
    response.headers.add("Access-Control-Allow-Origin", "http://localhost:8080")
    response.headers.add("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
    response.headers.add("Access-Control-Allow-Headers", "Content-Type, Authorization")
    return response

@airport_bp.route("/", methods=["GET"])
def get_airports():
    """Fetch all airports."""
    airports = Airport.query.all()
    return jsonify([airport.to_dict() for airport in airports]), 200

@airport_bp.route("/", methods=["POST"])
def add_airport():
    """Add a new airport."""
    data = request.json
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if Airport.query.filter_by(code=data.get("code")).first():
        return jsonify({"error": "Airport code already exists"}), 400

    new_airport = Airport(
        name=data["name"],
        code=data["code"],
        city=data["city"],
        country=data["country"]
    )
    db.session.add(new_airport)
    db.session.commit()

    return jsonify({"message": f"{data['name']} added successfully"}), 201

@airport_bp.route("/<int:id>", methods=["DELETE"])
def delete_airport(id):
    """Delete an airport."""
    airport = Airport.query.get(id)
    if not airport:
        return jsonify({"error": "Airport not found"}), 404

    db.session.delete(airport)
    db.session.commit()
    return jsonify({"message": "Airport deleted successfully"}), 200
