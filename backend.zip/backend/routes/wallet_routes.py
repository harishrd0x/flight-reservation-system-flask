from flask import Blueprint, request, jsonify
from models.wallet import Wallet
from models.user import User  # Import the User model
from extensions import db
from flask_jwt_extended import jwt_required, get_jwt_identity
from flask_cors import cross_origin
from decimal import Decimal

wallet_bp = Blueprint("wallet", __name__)

@wallet_bp.route("/", methods=["GET"])
@jwt_required()
@cross_origin(origins="http://localhost:8080")
def get_wallet():
    """
    Get the wallet information for the authenticated user and include the user's name and email.
    """
    user_id = get_jwt_identity()
    
    wallet = Wallet.query.filter_by(user_id=user_id).first()
    if not wallet:
        return jsonify({"error": "Wallet not found"}), 404
    
    user = User.query.get(user_id)
    
    # Get the wallet dictionary from your model's to_dict() method. If your model doesn't include user details,
    # add them manually.
    wallet_data = wallet.to_dict()
    wallet_data["userName"] = user.name if user else "Unknown User"
    wallet_data["email"] = user.email if user else "No email provided"
    
    return jsonify(wallet_data), 200

@wallet_bp.route("/add", methods=["POST"])
@jwt_required()
@cross_origin(origins="http://localhost:8080")
def add_funds():
    """
    Add funds to the authenticated user's wallet.
    Expects JSON payload with key "amount".
    """
    user_id = get_jwt_identity()
    data = request.json
    amount = data.get("amount")
    if amount is None:
        return jsonify({"error": "Amount is required"}), 400

    wallet = Wallet.query.filter_by(user_id=user_id).first()
    if wallet is None:
        # Create a wallet if none exists
        wallet = Wallet(user_id=user_id, balance=0)
        db.session.add(wallet)
    
    try:
        # Convert the incoming amount string to a Decimal to add to wallet.balance (which is decimal.Decimal)
        wallet.balance += Decimal(amount)
    except Exception as e:
        return jsonify({"error": "Invalid amount format", "message": str(e)}), 400

    db.session.commit()
    return jsonify({"message": "Funds added", "wallet": wallet.to_dict()}), 200
