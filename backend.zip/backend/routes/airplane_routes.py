from flask import Blueprint, request, jsonify
from flask_cors import CORS
from models.airplane import Airplane
from extensions import db

airplane_bp = Blueprint("airplane", __name__)
CORS(airplane_bp)  # This adds CORS headers to all responses on this blueprint

@airplane_bp.route("/", methods=["OPTIONS"])
def airplane_options():
    """Handle CORS preflight for the airplane endpoints."""
    response = jsonify({})
    response.headers.add("Access-Control-Allow-Origin", "http://localhost:8080")
    response.headers.add("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
    response.headers.add("Access-Control-Allow-Headers", "Content-Type, Authorization")
    return response, 200

@airplane_bp.route("/", methods=["GET"])
def get_airplanes():
    """
    Retrieve a list of all airplanes.
    """
    airplanes = Airplane.query.all()
    airplanes_data = [airplane.to_dict() for airplane in airplanes]
    return jsonify(airplanes_data), 200

@airplane_bp.route("/", methods=["POST"])
def create_airplane():
    data = request.json
    airplane = Airplane(
        model=data.get("model"),
        airline=data.get("airline"),
        capacity=data.get("capacity"),
        manufacture=data.get("manufacture")  # This field is expected!
    )
    db.session.add(airplane)
    db.session.commit()
    return jsonify({"message": "Airplane created successfully", "id": airplane.id}), 201

@airplane_bp.route("/<int:id>", methods=["DELETE"])
def delete_airplane(id):
    airplane = Airplane.query.get(id)
    if not airplane:
        return jsonify({"error": "Airplane not found"}), 404
    db.session.delete(airplane)
    db.session.commit()
    return jsonify({"message": "Airplane deleted successfully"}), 200
