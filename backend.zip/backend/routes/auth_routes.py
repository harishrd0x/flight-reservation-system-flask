from flask import Blueprint, request, jsonify
from models.user import User, UserRole  # Import UserRole from your model
from models.wallet import Wallet
from extensions import db, jwt
from security.password_utils import hash_password, verify_password
from security.jwt_auth import create_access_token
from flask_jwt_extended import jwt_required, get_jwt_identity

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/register", methods=["POST"])
def register():
    """Register a new user along with their wallet"""
    data = request.json

    # Check if email or mobile number already exists.
    if User.query.filter_by(email=data["email"]).first() or \
       User.query.filter_by(mobile_number=data["mobile_number"]).first():
        return jsonify({"error": "Email or mobile number already exists"}), 400

    hashed_pwd = hash_password(data["password"])
    
    # Force role to always be CUSTOMER using the enum member.
    role = UserRole.CUSTOMER

    # Create the user with the proper role.
    user = User(
        name=data["name"],
        email=data["email"],
        mobile_number=data["mobile_number"],
        password_hash=hashed_pwd,
        role=role
    )

    db.session.add(user)
    db.session.commit()

    # Create a wallet for the new user with a default balance of 0.00.
    wallet = Wallet(
        user_id=user.id,
        balance=0.00
    )
    db.session.add(wallet)
    db.session.commit()

    return jsonify({"message": "User registered successfully"}), 201

@auth_bp.route("/login", methods=["POST"])
def login():
    """Login user and return JWT token"""
    data = request.json
    # Use email for login.
    user = User.query.filter_by(email=data["email"]).first()

    if not user or not verify_password(data["password"], user.password_hash):
        return jsonify({"error": "Invalid credentials"}), 401

    # Convert user.id to a string to ensure the JWT 'sub' is a string.
    token = create_access_token(str(user.id))
    return jsonify({"access_token": token}), 200

@auth_bp.route("/logout", methods=["POST"])
@jwt_required()
def logout():
    """
    Logout endpoint.
    Implement token blacklisting if required.
    """
    return jsonify({"message": "Logout successful"}), 200

@auth_bp.route("/profile", methods=["GET"])
@jwt_required()
def get_profile():
    """Get logged-in user's profile"""
    user_id_str = get_jwt_identity()

    try:
        user_id = int(user_id_str)
    except ValueError:
        return jsonify({"error": "Invalid user identity in token"}), 400

    user = User.query.get(user_id)

    if not user:
        return jsonify({"error": "User not found"}), 404

    # When returning the user role, use the .value attribute to serialize the enum.
    return jsonify({
        "name": user.name,
        "email": user.email,
        "mobile_number": user.mobile_number,
        "role": user.role.value,
        "created_at": user.created_at.isoformat() if user.created_at else None
    }), 200
