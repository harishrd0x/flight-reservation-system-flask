from flask import Blueprint, request, jsonify
from models.flight import Flight, FlightStatus, FlightPrice, FlightClass
from extensions import db
from datetime import datetime

flight_bp = Blueprint("flight_bp", __name__, url_prefix="/flights")

@flight_bp.route("/", methods=["POST"])
def create_flight():
    """
    Create a new flight.
    ---
    tags:
      - Flight
    parameters:
      - in: body
        name: flight
        description: Flight object.
        schema:
          type: object
          required:
            - flight_name
            - airplane_id
            - source_airport_id
            - destination_airport_id
            - departure_time
            - arrival_time
            - status
          properties:
            flight_name:
              type: string
              example: "Flight 101"
            airplane_id:
              type: integer
              example: 1
            source_airport_id:
              type: integer
              example: 1
            destination_airport_id:
              type: integer
              example: 2
            departure_time:
              type: string
              format: date-time
              example: "2025-05-12T08:00:00"
            arrival_time:
              type: string
              format: date-time
              example: "2025-05-12T12:00:00"
            status:
              type: string
              enum: ['ACTIVE', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED']
              example: "ACTIVE"
    responses:
      201:
        description: Flight created successfully.
      400:
        description: Invalid input.
    """
    data = request.get_json()
    
    try:
        departure_time = datetime.fromisoformat(data["departure_time"])
        arrival_time = datetime.fromisoformat(data["arrival_time"])
    except Exception:
        return jsonify({"error": "Invalid date format. Use ISO8601 format."}), 400

    status_value = data.get("status", "ACTIVE")
    try:
        status_enum = FlightStatus(status_value)
    except ValueError:
        return jsonify({"error": "Invalid status. Choose from ACTIVE, IN_PROGRESS, COMPLETED, CANCELLED."}), 400

    flight = Flight(
        flight_name=data.get("flight_name"),
        airplane_id=data.get("airplane_id"),
        source_airport_id=data.get("source_airport_id"),
        destination_airport_id=data.get("destination_airport_id"),
        departure_time=departure_time,
        arrival_time=arrival_time,
        flight_status=status_enum
    )
    db.session.add(flight)
    db.session.commit()

    return jsonify({"message": "Flight created successfully", "flight": flight.to_dict()}), 201

@flight_bp.route("/", methods=["GET"])
def get_flights():
    """
    Retrieve all flights.
    ---
    tags:
      - Flight
    responses:
      200:
        description: A list of flights.
    """
    flights = Flight.query.all()
    return jsonify([flight.to_dict() for flight in flights]), 200

@flight_bp.route("/prices", methods=["POST"])
def create_or_update_flight_price():
    """
    Create or update a flight price.
    ---
    tags:
      - Flight Price
    parameters:
      - in: body
        name: flight_price
        description: Flight price object.
        schema:
          type: object
          required:
            - flight_id
            - flight_class
            - price
          properties:
            flight_id:
              type: integer
              example: 1
            flight_class:
              type: string
              enum: ['ECONOMY', 'BUSINESS']
              example: "ECONOMY"
            price:
              type: number
              example: 199.99
    responses:
      201:
        description: Flight price created successfully.
      200:
        description: Flight price updated successfully.
      400:
        description: Invalid input.
      404:
        description: Flight not found.
    """
    data = request.get_json()
    flight_id = data.get("flight_id")
    flight_class_value = data.get("flight_class")
    price = data.get("price")

    if not all([flight_id, flight_class_value, price]):
        return jsonify({"error": "Missing required fields"}), 400

    try:
        flight_class_enum = FlightClass(flight_class_value)
    except ValueError:
        return jsonify({"error": "Invalid flight class. Choose ECONOMY or BUSINESS."}), 400

    # Check if flight exists
    flight = Flight.query.get(flight_id)
    if not flight:
        return jsonify({"error": "Flight not found"}), 404

    # Check if a price record exists for this flight/class
    flight_price = FlightPrice.query.filter_by(flight_id=flight_id, flight_class=flight_class_enum).first()
    if flight_price:
        # Update the existing record
        flight_price.price = price
        db.session.commit()
        return jsonify({"message": "Flight price updated successfully", "flight_price": flight_price.to_dict()}), 200
    else:
        # Create a new flight price record
        flight_price = FlightPrice(flight_id=flight_id, flight_class=flight_class_enum, price=price)
        db.session.add(flight_price)
        db.session.commit()
        return jsonify({"message": "Flight price created successfully", "flight_price": flight_price.to_dict()}), 201
