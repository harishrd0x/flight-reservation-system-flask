# backend/models/user.py

from extensions import db
from sqlalchemy.types import TypeDecorator, String
import enum
from sqlalchemy import Sequence

# Custom type to allow case-insensitive enum conversion.
class CaseInsensitiveEnum(TypeDecorator):
    """
    A custom SQLAlchemy type that stores enums as uppercase strings.
    When binding a parameter (inserts/updates), it converts the value to uppercase.
    When retrieving a value, it converts it to uppercase and then loads the enum.
    """
    impl = String

    def __init__(self, enumtype, **kwargs):
        self.enumtype = enumtype
        # Optionally, you can specify the length of the underlying String column.
        super().__init__(**kwargs)

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        # If value is an enum member, use its value; if string, convert it.
        if isinstance(value, self.enumtype):
            return value.value.upper()
        return str(value).upper()

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        try:
            # Convert the database value to uppercase and then load the enum.
            return self.enumtype(value.upper())
        except ValueError:
            raise ValueError(f"Value {value} is not a valid {self.enumtype}")

# Define your user role enum.
class UserRole(enum.Enum):
    CUSTOMER = "CUSTOMER"
    ADMIN = "ADMIN"

class User(db.Model):
    __tablename__ = "users"
    
    # Use an Oracle sequence for generating primary keys.
    id = db.Column(db.Integer, Sequence('users_seq', start=1, increment=1), primary_key=True)
    
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    mobile_number = db.Column(db.String(15), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    # Use the custom CaseInsensitiveEnum for the role column.
    role = db.Column(CaseInsensitiveEnum(UserRole, length=20), nullable=False, default=UserRole.CUSTOMER)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "mobile_number": self.mobile_number,
            "role": self.role.value,  # This always returns an uppercase string.
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
