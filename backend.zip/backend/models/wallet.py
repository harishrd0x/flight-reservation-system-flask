from sqlalchemy import Column, Integer, Numeric, Sequence
from extensions import db

class Wallet(db.Model):
    __tablename__ = "wallets"
    
    # Define a sequence for Oracle
    id = Column(Integer, Sequence('wallet_seq', start=1, increment=1), primary_key=True)
    user_id = Column(Integer, nullable=False)
    balance = Column(Numeric, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "balance": float(self.balance)
        }
